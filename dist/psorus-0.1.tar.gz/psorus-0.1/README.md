# Grapa

This is a simple Package providing Layers for a Graph Neuronal Network written in Tensorflow and Keras, allowing you to chance the size of the Graph in various ways.

Take a look at the [documentation](https://grapa.readthedocs.io/en/latest/)

